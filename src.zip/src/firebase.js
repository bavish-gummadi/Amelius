import firebase from 'firebase'
const config = {
    apiKey: "AIzaSyAUnqxoRBnoQxIZMxPpXQf3LZ-18St1tzA",
    authDomain: "amelius-4076d.firebaseapp.com",
    databaseURL: "https://amelius-4076d.firebaseio.com",
    projectId: "amelius-4076d",
    storageBucket: "amelius-4076d.appspot.com",
    messagingSenderId: "578106619696"
  };
firebase.initializeApp(config);
export default firebase;
